package com.Webshop.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.Webshop.library.WebShop_BaseLibrary;

public class DemoWebShop extends WebShop_BaseLibrary{



	public DemoWebShop(WebDriver driver) 
	{
		this.driver=driver;		
		PageFactory.initElements(driver, this);
	}	



	@FindBy(how = How.XPATH, using="//a[text()='Log in']")
	public WebElement Login;

	@FindBy(how = How.XPATH, using="//input[@id='Email']")
	public WebElement UserNameTextField;

	@FindBy(how = How.XPATH, using="//input[@id='Password']")
	public WebElement PasswordTextField;

	@FindBy(how = How.XPATH, using="//input[@class='button-1 login-button']")
	public WebElement LoginSubmit;

	@FindBy(how = How.XPATH, using="(//a[@href='/books'])[1]")
	public WebElement Bookscatergory;


	@FindBy(how = How.XPATH, using="//a[text()='Health Book']")
	public WebElement HealthBook;

	@FindBy(how = How.XPATH, using="//*[@class='price-value-22']")
	public WebElement BookPrice;

	@FindBy(how = How.XPATH, using="//*[@id='add-to-cart-button-22']")
	public WebElement AddtoCart;

	@FindBy(how = How.XPATH, using="//input[@id='addtocart_22_EnteredQuantity']")
	public WebElement EnteredQuanity;

	@FindBy(how = How.XPATH, using="(//*[text()='Shopping cart'])[1]")
	public WebElement ShoppingCart;

	@FindBy(how = How.XPATH, using="//*[@class='order-summary-content']")
	public WebElement ShoppingCartEmpty;

	@FindBy(how = How.XPATH, using="//*[@class='qty-input valid']")
	public WebElement CartInputBox;

	@FindBy(how = How.XPATH, using="//input[@value='Update shopping cart']")
	public WebElement UpdateShoppingCart;

	@FindBy(how = How.XPATH, using="//*[@class='bar-notification success']")
	public WebElement AddCartNotificationMessage;

	@FindBy(how = How.XPATH, using="(//*[@class='product-price'])[1]")
	public WebElement SubTotalPrice;

	@FindBy(how = How.XPATH, using="//*[@id='checkout']")
	public WebElement CheckOutButton;

	@FindBy(how = How.XPATH, using="//*[@id='termsofservice']")
	public WebElement TermsandCondtions;

	@FindBy(how = How.XPATH, using="//*[@id='billing-address-select']")
	public WebElement BillingAddress;

	@FindBy(how = How.XPATH, using="(//*[@class='button-1 new-address-next-step-button'])[1]")
	public WebElement BillingAddressContinue; 

	@FindBy(how = How.XPATH, using="(//*[@onclick='Shipping.save()'])")
	public WebElement ShippingContinue;

	@FindBy(how = How.XPATH, using="//*[@id='shipping-address-select']")
	public WebElement ShippingAddressSelect;//*[@id='shippingoption_1']

	@FindBy(how = How.XPATH, using="//*[@id='shipping-address-select']")
	public WebElement ShippingMethod;
	
	@FindBy(how = How.XPATH, using="//*[@id='shippingoption_1']")
	public WebElement NextDayAirShippingMethod;

	@FindBy(how = How.XPATH, using="(//*[@onclick='ShippingMethod.save()'])")
	public WebElement ShippingMethodContinue; 

	@FindBy(how = How.XPATH, using="(//*[@onclick='PaymentMethod.save()'])")
	public WebElement PaymenthmethodContinue;

	@FindBy(how = How.XPATH, using="(//*[@onclick='PaymentInfo.save()'])")
	public WebElement PaymentInfoContinue;

	@FindBy(how = How.XPATH, using=" (//*[@onclick='ConfirmOrder.save()'])")
	public WebElement ConfirmContinueButton;

	@FindBy(how = How.XPATH, using="//*[text()='Your order has been successfully processed!']")
	public WebElement SuccessfullOrderMsg; 
	
	@FindBy(how = How.XPATH, using="//*[@value='Continue']")
	public WebElement FinalContinueButton;
	
	@FindBy(how = How.XPATH, using="//*[@class='ico-logout']")
	public WebElement LogOut;

}
