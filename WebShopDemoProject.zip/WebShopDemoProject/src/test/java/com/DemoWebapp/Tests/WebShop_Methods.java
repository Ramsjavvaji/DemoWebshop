package com.DemoWebapp.Tests;

import static org.testng.Assert.assertEquals;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.math3.util.Precision;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Webshop.library.DemoWebShopUtility;
import com.Webshop.pageobjects.DemoWebShop;
import com.relevantcodes.extentreports.LogStatus;

public class WebShop_Methods extends DemoWebShopUtility {


	DemoWebShop Demo;	

	public void demoWebshopTestMethod() throws Throwable {
		Demo = new DemoWebShop(driver);
		
//This method will check and  clear the items in shopping  cart
		clearCart();
		
		jsClick(Demo.Bookscatergory,"Click on books category");
		click(Demo.HealthBook,"Click on health book");
		kendoLoaderWait();
		String PriceDetails  =Demo.BookPrice.getText();
		System.out.println("The Book price details are" +" "+ PriceDetails);
		kendoLoaderWait();
		enterValue(Demo.EnteredQuanity, "2", "Quanity should be more than one");
		kendoLoaderWait();
		click(Demo.AddtoCart,"Add item to cart");
		kendoLoaderWait();
		kendoLoaderWait();
		verifyElementDisplayed(Demo.AddCartNotificationMessage, "Add Cart message should display");
		click(Demo.ShoppingCart,"Click on shoppingcart");
		verifyElementDisplayed(Demo.SubTotalPrice, "SubTotal price should display");
		kendoLoaderWait();
		jsClick(Demo.TermsandCondtions,"Click on Terms and condtions");
		kendoLoaderWait();
		click(Demo.CheckOutButton,"Click on Checkoutbutton");
		kendoLoaderWait();
		selectValueByVisbileText(Demo.BillingAddress, "demo test, Hitech City, Hyderabad 500081, India", "Select the Value from drop dropdown");
		
		//selectValueByValue(Demo.BillingAddress, "demo test, Hitech City, Hyderabad 500081, India", "Select the Value from drop dropdown");
		kendoLoaderWait();
		click(Demo.BillingAddressContinue,"Click on continue");
		kendoLoaderWait();
		selectValueByVisbileText(Demo.BillingAddress, "demo test, Hitech City, Hyderabad 500081, India", "Select the Value from same as billing address");
		click(Demo.ShippingContinue,"Click on continue button");
		kendoLoaderWait();
		click(Demo.NextDayAirShippingMethod,"Select the shipping methiod");
		click(Demo.ShippingMethodContinue,"Click on shipping Method continue");
		click(Demo.PaymenthmethodContinue,"Click on payment method continue");
		kendoLoaderWait();
		kendoLoaderWait();
		Thread.sleep(5000);
		String CODMsg=driver.findElement(By.xpath("//*[text()='You will pay by COD']")).getText();
		System.out.println(CODMsg);
		Assert.assertEquals("You will pay by COD", CODMsg);
		click(Demo.PaymentInfoContinue,"Click on paymentinfo continue button");
		click(Demo.ConfirmContinueButton,"Click on confirm button");
		kendoLoaderWait();
		Thread.sleep(5000);

		String OrderSuccessmsg=driver.findElement(By.xpath("//*[text()='Your order has been successfully processed!']")).getText();
		System.out.println(OrderSuccessmsg);
		kendoLoaderWait();
		kendoLoaderWait();
		Thread.sleep(5000);
		Assert.assertEquals("Your order has been successfully processed!", OrderSuccessmsg);
		click(Demo.FinalContinueButton,"Click on final continuebutton");
		Demo.LogOut.click();







	}
}