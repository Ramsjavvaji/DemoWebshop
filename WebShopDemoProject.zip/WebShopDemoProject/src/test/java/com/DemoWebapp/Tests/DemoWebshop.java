package com.DemoWebapp.Tests;

import org.testng.annotations.Test;

import com.Webshop.library.WebShop_BaseLibrary;
import com.relevantcodes.extentreports.LogStatus;

public class DemoWebshop extends WebShop_Methods{
	@Test
	public void WebShop_TestMethod() throws Throwable {
		startTest("DemoWebsiteValidation");
		
		try {
			Login(username, password);
			demoWebshopTestMethod();
			
		} catch (Exception e) {
			e.printStackTrace();
			logger.log(LogStatus.FAIL, "Execution got aborted due to "+e+logger.addScreenCapture(takeScreenShot(driver)));
		}
		reports.endTest(logger);
		reports.flush();
	}
	
}
