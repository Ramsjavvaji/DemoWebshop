package com.Webshop.library;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.Webshop.pageobjects.DemoWebShop;
import com.opencsv.CSVReader;
import com.relevantcodes.extentreports.LogStatus;

import io.codearte.jfairy.Fairy;
import io.codearte.jfairy.producer.person.Person;
import io.codearte.jfairy.producer.person.PersonProperties;

public class DemoWebShopUtility extends WebShop_BaseLibrary{


	DemoWebShop Demo;
		
	
	
	
	public void kendoLoaderWait() {	
		try {
			wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//*[@class='k-loading-image']")));		
		} catch (Exception e) {
		}
	}
	

	//=============================================//
	/*
	 * Wait for Elements Objects
	 */
	public void WaitForElement() 
	{
		wait = new WebDriverWait(driver, 60);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}
	//=============================================//

	/*
	 * wait until click is enabled and click
	 */
	public void click(WebElement ele, String ElementName) throws Throwable 
	{
		
		try 
		{	
			 new WebDriverWait(driver,40).ignoring(Exception.class).until(ExpectedConditions.visibilityOf(ele));
			waitForClickable(ele);
			Thread.sleep(500);
			if(ele.isDisplayed() && ele.isEnabled()) {
				//kendoLoaderWait();
				act = new Actions(driver);
				act.moveToElement(ele);		
				//HighlightElement(ele);
				ele.click();		
				System.out.println("Clicking on Element :: "+ElementName);
				logger.log(LogStatus.PASS,"Should click on "+ElementName, "Clicked on "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
			}
		} catch (Exception e) 
		{
			System.out.println("Not Clicking on Element :: "+ElementName);
			logger.log(LogStatus.FAIL,"Should click on "+ElementName, "Failed to click on "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}
	public void waitForClickable(WebElement ele) {
		try {
		new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(ele));
		}
		catch(Exception e)
		{
			
		}
	}
	
	

	/*
	 * MouseHover on an element
	 */
	public void mouseHover(WebElement ele, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.visibilityOf(ele));
			act = new Actions(driver);
			act.moveToElement(ele).build().perform();
			logger.log(LogStatus.PASS,"Should mouse hover on "+ElementName, "mouse hovered on "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			logger.log(LogStatus.FAIL,"Should mouse on "+ElementName, "Failed to mouse on "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}

	/*
	 * Click using JavaScript
	 */
	public void jsClick(WebElement ele, String ElementName) throws Throwable
	{
		try 
		{
			WebDriverWait wait2 = new WebDriverWait(driver, 60);
			wait2.until(ExpectedConditions.elementToBeClickable(ele));
			JavascriptExecutor js = (JavascriptExecutor)driver;			
			js.executeScript("arguments[0].click();", ele);
			System.out.println("Clicked on element using JSClick :"+ElementName);
			logger.log(LogStatus.PASS,"Should click on "+ElementName, "Clicked on "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			System.out.println("NotClicked on element using JSClick :"+ElementName);
			logger.log(LogStatus.FAIL,"Should click on "+ElementName, "Failed to click on "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}
	}

	/*
	 * Verify for an element and click on that element if it is displayed
	 */
	public void verifyIfDisplayAndClick(WebElement ele, String ElementName) throws Throwable
	{
		Thread.sleep(3000);	
		try {
			if(ele.isEnabled()) {
				JavascriptExecutor js = (JavascriptExecutor)driver;				
				js.executeScript("arguments[0].click();", ele);
				System.out.println(ElementName+" is displayed and clicked");
				logger.log(LogStatus.PASS,"Should click on "+ElementName, "Clicked on "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
			}
		} catch (Exception e) {
			System.out.println(ElementName+" is not displayed and clicked");
			logger.log(LogStatus.INFO,"Should click on "+ElementName, ElementName+" is not displayed and no need to click");
		}	

	}


	/*
	 * Verify for an element whether it is displayed or not
	 */
	public void verifyElementDisplayed(WebElement ele, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 15);	
			wait.until(ExpectedConditions.visibilityOf(ele));
			ele.isDisplayed();
			System.out.println(ElementName +" is displayed");
			logger.log(LogStatus.PASS,"Should display "+ElementName, "Displayed "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			System.out.println(ElementName+" is not displayed");
			logger.log(LogStatus.FAIL,"Should display "+ElementName, "Failed to display "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}	

	/*
	 * Verify for an element whether it is displayed or not
	 */
	public void verifyElementNotDisplayed(WebElement ele, String ElementName) throws Throwable 
	{
		try 
		{		
			ele.isDisplayed();
			logger.log(LogStatus.FAIL,"Should not display "+ElementName, "Displaying "+ElementName+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			System.out.println("Element is not displayed as expected for "+ElementName);
			logger.log(LogStatus.PASS,"Should not display "+ElementName, "Not Displayed "+ElementName+""+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
			
		}

	}
	/*
	 * Verify for an element whether it is enabled or not
	 */
	public void verifyElementEnabled(WebElement ele, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 15);	
			wait.until(ExpectedConditions.visibilityOf(ele));
			WaitForElement();			
			ele.isEnabled();
			logger.log(LogStatus.PASS,"Should Enable "+ElementName, "Enabled "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			logger.log(LogStatus.FAIL,"Should Enable "+ElementName, "Failed to Enable "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}
	
	/*
	 * Verify for an element whether it is enabled or not
	 */
	public void verifyElementdisabled(WebElement ele, String ElementName) throws Throwable 
	{
		try 
		{		
			ele.isEnabled();
			logger.log(LogStatus.FAIL,"Should disable "+ElementName, "Failed to disable "+ElementName +logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			logger.log(LogStatus.PASS,"Should disable "+ElementName, "Disabled "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}
	/*
	 * Sending values to the element
	 */
	public void enterValue(WebElement ele, String Value, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));			
//			ele.clear();
//			logger.log(LogStatus.PASS,"Should clear the field", "Cleared field successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
			ele.sendKeys(Value);
			System.out.println("Enterd data in field "+ElementName +" and Entered data is "+Value);
			logger.log(LogStatus.PASS,"Should Enter "+Value+"in field"+ElementName , "Entered "+Value+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			System.out.println("Not Enterd data in field "+ElementName +" and data to be Entered is "+Value);
			logger.log(LogStatus.FAIL,"Should Enter "+Value+"in field"+ElementName, "Failed to Enter "+Value+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}
	/*
	 * Sending values using JavaScript
	 */
	public void jsEnterValue(WebElement ele, String Value, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));			
			JavascriptExecutor js = (JavascriptExecutor)driver;		
			js.executeScript("arguments[0].value='"+Value+"';", ele);
			System.out.println("Enterd data in field "+ElementName +" using java script and Entered data is "+Value);
			logger.log(LogStatus.PASS,"Should Enter Value = "+Value, "Entered Value = "+Value+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));

		} catch (Exception e) 
		{
			logger.log(LogStatus.FAIL,"Should Enter "+Value, "Failed to Enter "+Value+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}
	}	

	/*
	 * Clear value in element
	 */
	public void clearEnterValue(WebElement ele) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));			
			ele.clear();
			System.out.println("Cleared data in field");
			logger.log(LogStatus.PASS,"Should clear the field", "Cleared field successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			System.out.println("Not cleared data in the field");
			logger.log(LogStatus.FAIL,"Should clear field","Failed to clear field due to ::"+e);
		}

	}
	/*
	 * Verify for an element whether it is displayed or not
	 */
	public void verifyIsDiaplyedAndEnterValue(WebElement ele, String Value, String ElementName) throws Throwable 
	{
		try 
		{
			WaitForElement();			
			if(ele.isDisplayed()) {				
				ele.clear();
				logger.log(LogStatus.PASS,"Should clear the field", "Cleared field successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
				ele.sendKeys(Value);
				logger.log(LogStatus.PASS,"Should Enter "+Value, "Entered "+Value+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
			}
		} catch (Exception e) 
		{
			logger.log(LogStatus.INFO,"Should Enter "+Value, "No Need to enter value");
		}

	}

	public void selectValueByIndex(WebElement ele, int Index, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));			
			new Select(ele).selectByIndex(Index);
			logger.log(LogStatus.PASS,"Should select "+Index+" for "+ElementName, "Selected "+Index+" successfully for "+ElementName+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			logger.log(LogStatus.FAIL,"Should select "+Index+"for "+ElementName,  "Failed to select "+Index+" for "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}

	public void selectValueByValue(WebElement ele, String Value, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));			
			new Select(ele).selectByValue(Value);
			logger.log(LogStatus.PASS,"Should select "+Value+" for "+ElementName, "Selected "+Value+" successfully for "+ElementName+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			logger.log(LogStatus.FAIL,"Should select "+Value+"for "+ElementName,  "Failed to select "+Value+" for "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}

	public void selectValueByVisbileText(WebElement ele, String Value, String ElementName) throws Throwable 
	{
		try 
		{
			wait = new WebDriverWait(driver, 20);
			wait.until(ExpectedConditions.elementToBeClickable(ele));				
			new Select(ele).selectByVisibleText(Value);
			logger.log(LogStatus.PASS,"Should select "+Value+" for "+ElementName, "Selected "+Value+" successfully for "+ElementName+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		} catch (Exception e) 
		{
			logger.log(LogStatus.FAIL,"Should select "+Value+"for "+ElementName,  "Failed to select "+Value+" for "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));
		}

	}

	
	

	public void isDeSelected(WebElement ele, String ElementName) throws Throwable {

		try {
			waitForVisibility(ele);
			if(!ele.isSelected()) {
				logger.log(LogStatus.PASS,"Should be in Unchecked State:: "+ElementName, "Is in UnChecked State:: "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));

			}
		} catch (Exception e) {
			logger.log(LogStatus.FAIL,"Should be in Unchecked State:: "+ElementName, "Is Not in UnChecked State "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));

		}

	}

	public void isSelected(WebElement ele, String ElementName) throws Throwable {

		try {
			waitForVisibility(ele);
			if(ele.isSelected()) {
				logger.log(LogStatus.PASS,"Should be in checked State:: "+ElementName, "Is in Checked State:: "+ElementName+" successfully"+"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));

			}
		} catch (Exception e) {
			logger.log(LogStatus.FAIL,"Should be in checked State:: "+ElementName, "Is Not in Checked State "+ElementName+" due to :: </br>"+ e +"<br/>"+logger.addScreenCapture(takeScreenShot(driver)));

		}

	}
	
	public void waitForVisibility(WebElement ele) throws Error, InterruptedException{
		new WebDriverWait(driver, 60).until(ExpectedConditions.visibilityOf(ele));
		Thread.sleep(200);
	}
	
	public void clearCart() throws Throwable {
		Demo=new DemoWebShop(driver);
		click(Demo.ShoppingCart,"Click on shopping cart");
		Thread.sleep(5000);
		try {
		if(driver.findElement(By.xpath("//*[@value='Update shopping cart']")).isDisplayed()){
			Demo.CartInputBox.click();
			Demo.CartInputBox.clear();
			enterValue(Demo.CartInputBox, "0", "Enter input as 0");
			kendoLoaderWait();
			click(Demo.UpdateShoppingCart,"Click on updateshopping cart");
		}
		
		else {
			click(Demo.HealthBook,"Click on books");
		}}
		
catch(Exception e) {
			
		}
	}
	
	
	public void Login(String Username, String Password) throws Throwable {
		Demo = new DemoWebShop(driver);
		click(Demo.Login,"Click on login button");
		kendoLoaderWait();
		String SignMeg= driver.findElement(By.xpath("//*[text()='Welcome, Please Sign In!']")).getText();
		System.out.println(SignMeg);
		Assert.assertEquals("Welcome, Please Sign In!", SignMeg);
		kendoLoaderWait();
		Demo.UserNameTextField.click();
		clearEnterValue(Demo.UserNameTextField);
		Demo.PasswordTextField.click();
		clearEnterValue(Demo.PasswordTextField);
		enterValue(Demo.UserNameTextField, Username, "Username Text Field");
		enterValue(Demo.PasswordTextField, Password, "Password Text Field");
		kendoLoaderWait();
		click(Demo.LoginSubmit,"Click on submit button");
		kendoLoaderWait();
		String AccountID=driver.findElement(By.xpath("//a[text()='testdemowebshop@gmail.com']")).getText();
		System.out.println(AccountID);
		Assert.assertEquals("testdemowebshop@gmail.com", AccountID);
	}
	
	public void logOut() {
		startTest("LogOut from application");
		Demo.LogOut.click();
	endTest();

	}
	}



