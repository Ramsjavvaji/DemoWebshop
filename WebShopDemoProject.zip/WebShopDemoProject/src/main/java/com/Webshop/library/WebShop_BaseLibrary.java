package com.Webshop.library;

import static org.monte.media.FormatKeys.EncodingKey;
import static org.monte.media.FormatKeys.FrameRateKey;
import static org.monte.media.FormatKeys.KeyFrameIntervalKey;
import static org.monte.media.FormatKeys.MIME_AVI;
import static org.monte.media.FormatKeys.MediaTypeKey;
import static org.monte.media.FormatKeys.MimeTypeKey;
import static org.monte.media.VideoFormatKeys.CompressorNameKey;
import static org.monte.media.VideoFormatKeys.DepthKey;
import static org.monte.media.VideoFormatKeys.ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE;
import static org.monte.media.VideoFormatKeys.QualityKey;

import java.awt.AWTException;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import org.apache.commons.io.FileUtils;
import org.monte.media.Format;
import org.monte.media.FormatKeys.MediaType;
import org.monte.media.math.Rational;
import org.monte.screenrecorder.ScreenRecorder;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import io.github.bonigarcia.wdm.WebDriverManager;

public class WebShop_BaseLibrary {
	
	public WebDriver driver;	
	public WebDriverWait wait;
	public static ExtentReports reports;
	public ExtentTest logger;	
	public static DateFormat dateformat = new SimpleDateFormat("MM-dd-yyyy HHmmss");
	public static Date date = new Date();	
	public static String reportLocation = System.getProperty("user.dir")+"\\Reports\\Reports_WebShop_"+dateformat.format(date)+"\\";
	public Actions act;
	public Properties prop;
	public static ScreenRecorder screenRecorder;
	
	
	public String username ="testdemowebshop@gmail.com";
	public String password ="Test123";
	
	/*
	 * This Method will Initialize properties file to read configuration data
	 * Example URL, UserName, Password etc..
	 */
	public void initialize() throws FileNotFoundException, IOException	{
		prop = new Properties();
		File file = new File(".//DemoWebShop.properties");
		FileInputStream fileInput = new FileInputStream(file);	    
		prop.load(fileInput);
		fileInput.close();		
	}


	/*
	 * This Method will Initialize extent reports and screen recording for the tests
	 * This method has TestNG before suite annotation which will be called at very first while execution
	 */
	@BeforeSuite
	public void invokeReports() throws IOException, AWTException {	

		reports = new ExtentReports(reportLocation+"Reports_"+dateformat.format(date)+".html");	
		//Create a instance of GraphicsConfiguration to get the Graphics configuration
		//of the Screen. This is needed for ScreenRecorder class.
		GraphicsConfiguration gc = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice().getDefaultConfiguration();

		//Create a instance of ScreenRecorder with the required configurations
		screenRecorder = new ScreenRecorder(gc, new Format(MediaTypeKey, MediaType.FILE, MimeTypeKey, MIME_AVI),
				new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE,
						CompressorNameKey, ENCODING_AVI_TECHSMITH_SCREEN_CAPTURE, DepthKey, (int)24, FrameRateKey, Rational.valueOf(15),
						QualityKey, 1.0f, KeyFrameIntervalKey, (int) (15 * 60)),
				new Format(MediaTypeKey, MediaType.VIDEO, EncodingKey,"black", FrameRateKey, Rational.valueOf(30)), null);
		screenRecorder.start();
	}	


	/*
	 * This Method will Initialize Browser instances
	 * Example Chrome, Firefox and IE.. 
	 */
	@BeforeClass	
	public void setUp() throws Exception {
		/*
		 * This method will call properties file before every test fectching class
		 */
		initialize();

		/*
		 * Adding environment details to the reports before execution
		 */
		reports
		.addSystemInfo("Environment URL", prop.getProperty("URL"));
		//.addSystemInfo("Build Version", prop.getProperty("BuildVersion"));

		/*
		 * This condition will invoke Chrome browser 
		 */
		if(prop.getProperty("browser").equalsIgnoreCase("chrome")) {			
			startTest("Invoke Chrome Browser");			
			WebDriverManager.chromedriver().setup();			
			Map<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_setting_values.notifications", 2);
			chromePrefs.put("profile.content_settings.exceptions.automatic_downloads.*.setting", 1);
			chromePrefs.put("download.prompt_for_download", false);
			chromePrefs.put("download.directory_upgrade", true);
			chromePrefs.put("safebrowsing.enabled", true);
			ChromeOptions options = new ChromeOptions(); 
			options.setExperimentalOption("prefs", chromePrefs);
			options.setExperimentalOption("useAutomationExtension", false);
			options.setExperimentalOption("excludeSwitches",Collections.singletonList("enable-automation"));
//			options.addArguments("user-data-dir="+System.getProperty("user.home")+"\\AppData\\Local\\Google\\Chrome\\User Data\\Default"); 
			options.addArguments("--start-maximized");			
			options.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			driver = new ChromeDriver(options);	
			driver.manage().getCookies();
			logger.log(LogStatus.INFO, "Opened Chrome browser successfully");
			driver.get(prop.getProperty("URL"));			
			logger.log(LogStatus.PASS,"Should URL = "+prop.getProperty("URL"), "Opened "+prop.getProperty("URL")+" successfully");
			reports.endTest(logger);
		}
		/*
		 * This condition will invoke Firefox browser 
		 */
		else if(prop.getProperty("browser").equalsIgnoreCase("firefox")) {
			startTest("Invoke Firefox Browser");
			WebDriverManager.firefoxdriver().setup();
			FirefoxOptions options  = new FirefoxOptions();
			options.addArguments("--start-maximized");
			driver = new FirefoxDriver(options);
			logger.log(LogStatus.INFO, "Opened Firefox browser successfully");			
			driver.manage().window().maximize();
			driver.get(prop.getProperty("URL"));
			logger.log(LogStatus.PASS,"Should URL = "+prop.getProperty("URL"), "Opened "+prop.getProperty("URL")+" successfully");
			reports.endTest(logger);			

		}
		/*
		 * This condition will invoke IE browser 
		 */
		else if(prop.getProperty("browser").equalsIgnoreCase("IE")) {			
			startTest("Invoke Internet Explorer Browser");
			WebDriverManager.iedriver().setup();
			driver = new InternetExplorerDriver();
			driver.manage().window().maximize();
			logger.log(LogStatus.INFO, "Opened IE browser successfully");
			driver.get(prop.getProperty("URL"));
			logger.log(LogStatus.PASS,"Should URL = "+prop.getProperty("URL"), "Opened "+prop.getProperty("URL")+" successfully");			
			reports.endTest(logger);
		}
		/*
		 * This condition will show warning if no browser is initiated
		 */
		else {
			startTest("Verify Browser Parameter Value");
			logger.log(LogStatus.WARNING, "Check browser parameter value in Configuration","There is not value set for browser");
			reports.endTest(logger);			
		}
	}

	/*
	 * This method will end a method test after every test method
	 */

	@AfterMethod
	public void endTest() {
		reports.endTest(logger);
			
	}

	/*
	 * This method will close the driver instance for a test class after all test methods execution
	 */

	@AfterClass
	public void tearDownBrowsers() {	
		driver.close();
		driver.quit();
		logger.log(LogStatus.INFO,"Should close browser", "Closed browser successfully");
	}	

	/*
	 * This method will close reports, screen recorder after all the test class file executions
	 */
	@AfterSuite
	public void closeReports() throws IOException {		
		reports.close();
		screenRecorder.stop();
		List<File> createdMovieFiles = screenRecorder.getCreatedMovieFiles();
		for(File movie : createdMovieFiles){
			System.out.println("New movie created: " + movie.getAbsolutePath());
		}
	}

	/*
	 * This method is a short cut key to initiate extent reports start logger
	 */
	public void startTest(String description) {
		System.out.println("Testing started for : "+description);
		logger = reports.startTest(description);
	}

	/*
	 * This Method will generate random UUID screenshot with names for pass or failue steps
	 */
	public static String takeScreenShot(WebDriver driver) throws Throwable {
		UUID uuid = UUID.randomUUID();
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);		
		FileUtils.copyFile(scrFile, new File(reportLocation+uuid+".png"));
		return uuid+".png";		
	}

}
